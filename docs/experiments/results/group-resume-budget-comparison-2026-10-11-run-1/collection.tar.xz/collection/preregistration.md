# EXP-006-03：共享 Gateway 的恢复尝试次数对照

Date: 2026-10-11
Status: 设计、比较入口及工具验收完成；正式非 race 测量待执行。
Related: [设计与方案权衡](../worklog/2026-10-11-group-resume-budget-design.md)、[EXP-006-02](group-resume-baseline.md)、[Milestones](../MILESTONES.md)。

## Goal / Questions

在八场共享原 Gateway、原 Worker RPC 的条件下，只改变客户端 MaxAttempts（5 → 8），比较真实握手占位后的恢复完整性与成本。重新运行同版本五次对照，历史基线只提供问题背景。

1. 入口占位 2s 时，多三次机会是否能等到开放，并完整完成原场？
2. 占位 500ms、开放后仍竞争时，增加次数是否改变完整完成率？
3. 获得多少完成场，同时增加多少实际请求、拒绝和等待？
4. 失败返回是否变晚，原 RPC 和整批资源是否更早自然释放？

本轮不寻找最优次数，不改变退避算法或生产默认值，不用于推断真实 ASR、生产容量或长时多次故障的恢复 SLO。

## Hypothesis / 预算语义

五次预算在快速拒绝时理论尝试约为 0、0.1、0.3、0.7、1.5s，可能早于 2s 开放耗尽。八次额外机会约在 2.5、3.5、4.5s，可能接回并承受开放后的竞争，但仍可能全部失败或先触及 5s 窗口。

以上相对第一次恢复尝试、忽略 I/O 与清理耗时，不是相对代理 T0 的精确排期。窗口包含清理、退避和握手；次数是整场 Run 累计 resume Dial，首次 start 不计，成功不清零。本轮每场全新 Run、一次统一断线；成功 ready 清除该轮时间截止点，不重置次数。

## Setup / 固定条件

### 共享链路、输入与故障

- 每批一个公开 v2 Gateway、一个 TCP gRPC 位置 Worker、一个故障代理，八个独立 V2Client Run；共享 gate、tracker、registry 和 Worker 连接。独立流每块处理 10ms，不另设跨流计算名额。
- 每场 PCM 16kHz/单声道/16bit，60 块 × 3200 字节 = 192000 字节，固定 100ms 采集节奏；位置/实验编号确定输入，八场不同，逐字验证。处理每块产生一条位置结果，EOF 后一条尾部结果，完整场应用 61 个连续序号。
- 顺序启动：每场 ready 转发且首次 Read 被观察到后再启动下一场，不人为阻塞首次 Read。八场首读跨度上限 50ms。
- 在每场初始连接第 20 块 `[60800,64000)` 建立屏障，前 19 块正常转发；最多暂扣一块。全员到达且八条原 RPC 活跃后，两条真实升级、未发首消息的连接占满握手名额。
- 在共同故障时刻 T0 并发切断八条原连接的前后端，丢弃暂扣块，源继续采集。切断完成跨度上限 50ms；初始建立不完整时不伪造完整群体故障。
- 每次恢复立即经过同一个 Gateway；真实 HTTP 503 / handshake_limit 及转发事实分别记录。占位连接在 T0+500ms 或 T0+2s 关闭，handler 返回且名额归还后记录实际释放时刻。
- 各批重新创建夹具；整批自然空闲后才进入下一批。故障是断线加入口占位，不是 TCP 丢包、网络黑洞或实例崩溃。

### 除次数之外保持一致

| 范围 | 固定值 |
| --- | --- |
| 客户端输入/缓冲 | Realtime=true，ChunkBytes=3200，MaxReplayBytes=320000，MaxReplayChunks=128，ReadLimit=65536 |
| 客户端期限 | HandshakeTimeout=10s，WriteTimeout=5s，ApplyTimeout=5s，CompletionTimeout=30s |
| 恢复 | 启用；Window=5s，InitialBackoff=100ms，MaxBackoff=1s；首次立即，后续确定性指数退避，无 jitter |
| Gateway | MaxSessions=8，MaxMessageBytes=1048576，WorkerSendTimeout=2s，ResultWriteTimeout=2s，StartTimeout=10s，MaxPendingAudioBytes=0 |
| v2 入口/保留 | MaxHandshakes=2，EntryTimeout=10s，InputProgressTimeout=30s，ResumeWindow=10s，ResultRetentionTimeout=10s，WorkerStatusTimeout=2s |
| v2 缓冲 | 音频/结果字节上限各 1048576；块数/结果数上限各 256 |
| 观察 | 从首个 Run 启动起 15s，其中 ready 等待最多 10s；全部 Run 返回后另观察自然清理最多 15s；最终取消单独记账 |
| 采样/同步 | 资源采样周期 10ms；首读及切断完成跨度各 ≤50ms；保存实际采样间隔、采样调用耗时和采集落后 |
| 构建/环境 | 同一源码快照、一次非 race 构建、同进程 loopback；不与其他实验或 race 测试并行；保存 Go/OS/硬件、GOMAXPROCS 和影响运行的环境变量 |

每一相邻对内，仅 MaxAttempts 不同；Case 标记、顺序和临时网络地址不是业务变量。D/E 之间只有占位时长不同。macOS 正式采集沿用脚本自有 caffeinate，记录提前退出及采样异常；保持唤醒不等于已证明主机从未短暂停顿。

### 四个条件与固定顺序

| 条件标记 | 占位 | MaxAttempts | 正式批数 | 计划场数 |
| --- | --- | ---: | ---: | ---: |
| D_busy_500ms_a5 | 500ms | 5 | 3 | 24 |
| D_busy_500ms_a8 | 500ms | 8 | 3 | 24 |
| E_busy_2s_a5 | 2s | 5 | 3 | 24 |
| E_busy_2s_a8 | 2s | 8 | 3 | 24 |

| 轮次 | 第一批 | 第二批 | 第三批 | 第四批 |
| --- | --- | --- | --- | --- |
| 1 | D_busy_500ms_a5 | D_busy_500ms_a8 | E_busy_2s_a8 | E_busy_2s_a5 |
| 2 | D_busy_500ms_a8 | D_busy_500ms_a5 | E_busy_2s_a5 | E_busy_2s_a8 |
| 3 | D_busy_500ms_a5 | D_busy_500ms_a8 | E_busy_2s_a8 | E_busy_2s_a5 |

共 12 批、96 个计划会话，六对相邻条件；总计五次先行和八次先行各三对，每个场景内部仍为 2:1 / 1:2，顺序影响没有完全消除。相邻对是两个独立批次，不是同一个会话先后改预算；相同实验编号只表示固定输入相同。

每批最多 40 或 64 次恢复 Dial，上限差 24，不是测得的新增请求数。正式总恢复 Dial 上限为 624，不含 96 次初始 start 和测试占位连接。probe、预热及反例不计正式分母；工具不因某个业务结果失败而重复该批换取成功。

## Metrics / 比较口径

| 指标 | 口径与输出 |
| --- | --- |
| 主指标：完整完成率 | 核实 completed、逐字完整音频、连续完整结果及完成确认写出；每条件完整场 / 24，逐批完整场 / 8。失败、未知分别列出；分母始终包含全部计划场 |
| 完成差 | 每个场景八次减五次的完成数及完成率差（百分点）；同时列三轮相邻批次差，不用历史基线当作本轮对照 |
| 实际请求成本 | 每场/每批 resume Dial、代理到达、解析 resume、后端请求四层数量和拒绝码；按计划场均值及相邻对差展示，不假设四层总相等 |
| 请求聚集 | 从 T0 至整批 Run 返回，以固定 50ms 桶记录首波（connection=2）、后续重试、实际拒绝及空桶；不把同桶等同精确同时，也不把入口到达当接纳 |
| 恢复与新音频 | T0→ready、实际全部占位释放→ready；T0 后/释放后首次开始 Read 的块被结果覆盖并成功应用的等待，分别列样本数与 null |
| 转录与失败等待 | 完整场最大相邻 partial 间隔、实际采集/计划采集到应用的等待；全部场 T0→Run 返回、错误类别、尝试数和外层到期事实。失败场的断线前 partial 不代表已恢复 |
| 音频代价/缺口 | 代理重复音频负载；计划、采集、Worker 接收与处理范围；已采集未接收、已采集未处理、尚未采集分别列出，不能当作 TCP 丢包量 |
| 原流保留 | 每条原 RPC 的 T0→worker.exited_at，以及该 RPC 退出减其客户端返回的非负等待；每批八条故障后保留时长之和（RPC·秒），不是 CPU 时间或逻辑会话退出时刻 |
| 整批清理 | T0→整批自然空闲、最后一个 Run 返回→整批自然空闲；另列强制清理/未观察到。旧逐场 remote_idle_after_return 使用整批空闲，不能当作该场释放时间 |
| 资源与证据质量 | 会话、注册、原流、握手/代理任务、整进程 goroutine/heap 采样及最大间隔；首读/切断跨度、采集落后、采样调用耗时。采样峰值不是严格上界或单会话内存 |

保存逐场与逐批结果，按条件汇总 min/median/max，附有效样本数和失败/未知数；中位数从原始场样本合并重算，不平均批次中位数。三批小样本不报告可靠 p99 或统计显著性；两种预算成功者可能不同，不称为逐会话配对延迟收益。

失败终止依据结合实际次数、错误链和时刻说明；仅凭 recovery_exhausted 不能断言是次数还是窗口，代理 T0 也不是客户端内部窗口起点。无法明确区分时标记未知，不凭理论排期补造事实。未恢复、未退出等未测事件用 null，不能填零。

## Acceptance / 证据与结论

1. **配置与分母可复核。**新实验身份、12 批顺序、96 个计划场、实际两种次数和其余固定条件都独立核对；缺批、重复、条件漂移及源码变动不能静默通过。
2. **正确性不折抵。**全体原 RPC 归属不变，不回退 start、不串场；完整场音频与结果逐项核实，源关闭一次。业务失败保留，错误分类与事实一致。
3. **故障与自然清理有证据。**两条真实占位连接、八场故障覆盖及实际释放均核对；50ms 同步判据沿用。不能把最终取消后的零计数作为自然归零。
4. **工具合格不要求八次更好。**不预设必须 24/24 或必须提升多少；若更多尝试无改善、拒绝增多或等待变长，按实测报告，不增加次数重测来改结论。
5. **数据质量与业务结果分开。**原始报告/错误全部保留；配置、同步或证据校验失败的场仍占计划分母，不能冒充明确业务失败或从分母删除。存在未知时不给出无条件的确定完成率差，只列已核实完成/计划、未知数与可能范围。采样缺口限制资源时序结论，不以事件正确自动证明连续资源状态。

结论模板仅在测量后填数：

> 在固定八场共享入口、___ 占位条件下，五次完成 ___/24，八次完成 ___/24，相差 ___ 个百分点；实际恢复请求 ___→___，失败 ___→___，未知 ___/___。成功场新音频等待及原 RPC 保留成本分别为 ___。该结论只覆盖本轮条件。

若增加次数支持等待开放，再独立设计 jitter 来比较请求分散；若仍失败，先从实际到达、拒绝、窗口和保留事实解释，不同时修改窗口/间隔/入口名额。

## Tool plan / 实现前固定

- 助手新增 EXP-006-03 显式入口和固定轮次，复用共享夹具；默认跳过正式实验。用缩短预算的真实网络 probe 验收两种配置，业务失败仍输出报告。
- 采集/分析增加明确实验配置，独立核对以上顺序、条件和比较指标。保留 EXP-006-02 五次契约；八次报告不能通过旧基线身份的验证。
- 覆盖历史兼容、次数/窗口/退避漂移、批次缺失重复、错误顺序、失败分母、资源时间口径及音频/结果反例。复核不覆盖初次产物。
- 工具验收完成后补实际运行命令。正式运行一次构建、三轮，独占新输出目录，保存源码/工具/预登记/二进制/环境/原始事件/退出状态和 SHA256；独立复算并读回归档。

本页尚无 EXP-006-03 正式预算对照结果。工具失败或环境中断保留首次尝试；若需要复测，另建完整目录并说明原因，不拼接不同版本、不同运行的批次。

## 工具验收与命令（2026-10-11）

比较入口已接通，正式入口内部执行固定三轮，采集命令的 `--count` 是逻辑轮次；测试程序始终 `-test.count=1`，不会重复三轮变成九轮。报告保存 experiment、round、实际客户端/Gateway 条件，分析分别核对原 RPC 退出与整批空闲。

真实非 race 的缩短版 probe 先一轮四批接通，再独立三轮验证交替顺序：三轮 12/12 批、96 场证据合格，72 完成、24 明确失败，5474 个资源样本且均自然清理。此处占位实际为 40ms/300ms、输入 800ms，**不是本页正式 500ms/2s 条件的结果**；详细条件、首次人工夹具失败和证据范围见[工具验收](../worklog/2026-10-11-group-resume-budget-design.md#工具实现与验收2026-10-11)。

缩短场景的采集与测试：

```sh
PYTHONDONTWRITEBYTECODE=1 GOCACHE=/private/tmp/tide-review-gocache \
  GOPROXY=off GOSUMDB=off \
  python3 docs/experiments/scripts/run_group_resume_budget.py \
  --mode probe --count 3 --output /private/tmp/tide-group-budget-tools-new-run

PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s docs/experiments/scripts -p 'test_group_resume*.py'
```

正式采集命令（本步未运行）：

```sh
PYTHONDONTWRITEBYTECODE=1 GOCACHE=/private/tmp/tide-review-gocache \
  GOPROXY=off GOSUMDB=off \
  python3 docs/experiments/scripts/run_group_resume_budget.py \
  --mode formal --count 3 --output /private/tmp/tide-group-budget-formal-new-run
```

独立复核写入另一个新目录，不覆盖初次分析：

```sh
PYTHONDONTWRITEBYTECODE=1 python3 docs/experiments/scripts/summarize_group_resume_budget.py \
  /private/tmp/tide-group-budget-formal-new-run \
  --output /private/tmp/tide-group-budget-formal-new-run/reanalysis-1
```

`summary.json` 包含四条件、六对相邻比较及两个场景的总差值；无效或未知证据不输出确定收益。原始报告、逐场和请求桶 CSV、源码/产物/环境与分析摘要另存。归档移动后按原命令记录核对原采集路径，实际从新位置复核文件摘要；不要求原目录继续存在。

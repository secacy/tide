"""Mutate copies of actual paired evidence; preserve all original observations."""
from pathlib import Path
import json,shutil,sys,tempfile
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source/experiments/asrquality'))
from compare_decoding import PLAN,compare
results=[]
for kind in ['wrong_method','wrong_path_budget','different_wav','rewritten_text','missing_release','failed_slot','missing_slot']:
    with tempfile.TemporaryDirectory() as tmp:
        target=Path(tmp)
        for name in ['baseline','before-run.json','execution.json']+PLAN:
            p=root/name
            if p.is_dir():shutil.copytree(p,target/name)
            else:shutil.copyfile(p,target/name)
        if kind in ['failed_slot','missing_slot']:
            path=target/'execution.json'
            value=json.loads(path.read_text())
            if kind=='failed_slot':
                value[0]['exit_code']=124
                value[0]['timed_out']=True
            else:value.pop()
        else:
            path=target/'B_q01/summary.json'
            value=json.loads(path.read_text())
            if kind=='wrong_method':value['decoding']['method']='greedy_search'
            elif kind=='wrong_path_budget':value['decoding']['max_active_paths']=8
            elif kind=='different_wav':value['file_sha256']['input.wav']='other'
            elif kind=='rewritten_text':value['metrics']['last_text_snapshot']='伪造的优质结果'
            else:value['metrics']['close_returned']=False
        path.write_text(json.dumps(value,ensure_ascii=False)+'\n')
        try:
            result=compare(target)
            rejected=not result['all_six_pairs_complete'] and result['cer_reduction_percentage_points'] is None
        except ValueError:
            rejected=True
        if not rejected:raise RuntimeError('accepted bad comparison: '+kind)
        results.append({'case':kind,'prevented_valid_full_comparison':True})
print(json.dumps(results,indent=2))

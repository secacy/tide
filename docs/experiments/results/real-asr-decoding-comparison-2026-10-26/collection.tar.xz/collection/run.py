"""Execute the frozen twelve-slot plan; preserve every slot and every failure."""
from pathlib import Path
import datetime, json, subprocess
root=Path('/private/tmp/tide-decoding-comparison-2026-10-26-1')
plan=json.loads((root/'before-run.json').read_text())
inputs=Path('/Users/can/src/golang/tide-personal/testdata/asr-quality/self-recorded-2026-10-26')
rows=[{'name':name,'exit_code':None,'timed_out':False,'started_utc':None,'ended_utc':None} for name in plan['plan']]
(root/'execution.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
    group,case=row['name'].split('_')
    settings=plan['search_settings'][group]
    command=['/private/tmp/tide-decoding-probe-2026-10-26','-model-dir','/private/tmp/tide-asrprobe-assets-2026-10-25','-wav',str(inputs/'pcm'/(case+'.wav')),'-output',str(root/row['name']),'-threads','2','-realtime=true','-decoding-method',settings['method'],'-max-active-paths',str(settings['max_active_paths'])]
    row['command']=command
    row['started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (root/(row['name']+'.stdout')).open('xb') as stdout, (root/(row['name']+'.stderr')).open('xb') as stderr:
        try:
            row['exit_code']=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=plan['process_timeout_seconds']).returncode
        except subprocess.TimeoutExpired:
            row['exit_code']=124
            row['timed_out']=True
    row['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (root/'execution.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(row['name'],row['exit_code'],flush=True)

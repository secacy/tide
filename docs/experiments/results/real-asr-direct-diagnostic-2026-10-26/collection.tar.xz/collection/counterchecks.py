"""Replay actual diagnostic evidence mutations; never modify the recorded run."""
from pathlib import Path
import json, shutil, sys, tempfile
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'source/experiments/asrquality'))
from compare_probe import compare
names = ['baseline', 'q04', 'q05', 'before-run.json', 'execution.json']
results = []
for kind in ['rewritten_direct_text', 'different_input_wav', 'missing_direct_release', 'wrong_padding', 'changed_baseline']:
    with tempfile.TemporaryDirectory() as tmp:
        target = Path(tmp)
        for name in names:
            p = root/name
            if p.is_dir(): shutil.copytree(p, target/name)
            else: shutil.copyfile(p, target/name)
        path = target/'q04/summary.json'
        value = json.loads(path.read_text())
        if kind == 'rewritten_direct_text': value['metrics']['last_text_snapshot'] = '伪造的正确文本'
        elif kind == 'different_input_wav': value['file_sha256']['input.wav'] = 'wrong'
        elif kind == 'missing_direct_release': value['metrics']['close_returned'] = False
        elif kind == 'wrong_padding': value['metrics']['leading_padding_samples'] = 4801
        else:
            path = target/'baseline/summary.json'
            value = json.loads(path.read_text())
            value[3]['report']['transcript'] = '静默改写旧结果'
        path.write_text(json.dumps(value, ensure_ascii=False)+'\n')
        try:
            report = compare(target)
            rejected = report['completed'] < 2 and report['unknown'] > 0
        except ValueError:
            rejected = True
        if not rejected: raise RuntimeError('undetected corruption: '+kind)
        results.append({'case': kind, 'rejected': rejected})
print(json.dumps(results, ensure_ascii=False, indent=2))

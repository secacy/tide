from pathlib import Path
import datetime, json, subprocess
root = Path('/private/tmp/tide-quality-direct-2026-10-26-1')
inputs = Path('/Users/can/src/golang/tide-personal/testdata/asr-quality/self-recorded-2026-10-26')
rows = []
for name in ['q04', 'q05']:
    row = {'name': name, 'exit_code': None, 'timed_out': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    command = ['/private/tmp/tide-asr-quality-direct-probe-2026-10-26', '-model-dir', '/private/tmp/tide-asrprobe-assets-2026-10-25', '-wav', str(inputs/'pcm'/(name+'.wav')), '-output', str(root/name), '-threads', '2', '-realtime=true']
    row['command'] = command
    with (root/(name+'.stdout')).open('xb') as stdout, (root/(name+'.stderr')).open('xb') as stderr:
        try:
            row['exit_code'] = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=60).returncode
        except subprocess.TimeoutExpired:
            row['timed_out'] = True
            row['exit_code'] = 124
    row['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    rows.append(row)
    (root/'execution.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(name, row['exit_code'], flush=True)

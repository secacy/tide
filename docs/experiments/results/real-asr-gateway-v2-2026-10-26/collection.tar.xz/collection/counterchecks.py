import json,runpy,shutil,sys,tempfile
from pathlib import Path
verify=runpy.run_path(str(Path(__file__).with_name("verify.py")))["verify_gateway"]
raw,manifest=map(Path,sys.argv[1:])
results=[]
for kind in ["false_progress","false_completion_ack","changed_forwarded_hash","rewritten_callback"]:
    with tempfile.TemporaryDirectory() as td:
        data=Path(td)/"data";shutil.copytree(raw,data)
        reports=json.loads((data/"summary.json").read_text())
        if kind=="false_progress":reports[0]["processed_audio_bytes"]=reports[0]["input_bytes"]
        if kind=="false_completion_ack":reports[0]["client"]["CompletionAckWritten"]=False
        if kind=="changed_forwarded_hash":
            reports[0]["grpc"]["audio_sha256"]="0"*64
            (data/"speech0-grpc.json").write_text(json.dumps(reports[0]["grpc"]))
        if kind=="rewritten_callback":
            events=[json.loads(x) for x in (data/"speech0.jsonl").read_text().splitlines()]
            events[0]["message"]["text"]="changed callback"
            (data/"speech0.jsonl").write_text("".join(json.dumps(x)+"\n" for x in events))
        (data/"summary.json").write_text(json.dumps(reports))
        try:verify(data,manifest)
        except AssertionError:results.append({"case":kind,"rejected":True})
        else:raise AssertionError(kind)
print(json.dumps(results,indent=2))

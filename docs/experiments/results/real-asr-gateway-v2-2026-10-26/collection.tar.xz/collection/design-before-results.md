# 第七阶段：真实模型经 Gateway/v2 的短音频闭环

日期：2026-10-26。承接 [原生 Worker 验收](2026-10-26-sherpa-engine-assembly.md)。当前为实现前验收设计，运行结果随后补充。

## 目标与方案选择

验证生产 V2Client → 真实 WebSocket → 生产 Gateway → 真实 TCP gRPC → 独立原生 Worker 进程。已有直接 gRPC 结果不能证明 Gateway 音频封装、结果序号、应用确认及 completed 兼容真实模型，因此本步检查这些连接处。

选择在测试中组装生产 Gateway 处理器和 V2Client，使用临时 HTTP 端口、真实网络及独立 Worker 进程。相比把三个命令进程全部启动，可直接观察 Gateway 活动数和成功转发的 gRPC 音频/结果，也不需要扩展目前固定 v1 路径的演示客户端。代价是本轮不覆盖 cmd/gateway 启动配置/信号与演示客户端命令。相比替身 Worker，本轮使用固定真实模型，保留加载、尾部和释放行为。

助手负责集成测试、观察、运行与证据，不为测试改动业务状态机或真实模型输出。复用已有启动/音频读取测试工具，避免复制原生实现。

## 固定条件

- 与前轮相同的绑定、模型 revision/文件 SHA、CPU 两线程、前后 padding、无 endpoint/reset；使用非 race Worker 可执行程序。正式数据使用非 race 测试驱动，race 验证另外执行。
- Gateway MaxSessions=1、MaxPendingAudioBytes=0，启用 v2，其余 V2 预算使用默认值，含 ResumeWindow=10s、ResultRetentionTimeout=30s。显式关闭的是未知处理位置的积压预算，其他生命周期/缓冲保护继续生效。
- V2Client ChunkBytes=3200、Realtime=true、Resume=nil；无断网注入、无自动恢复。本轮保持单场顺序运行，不测容量。
- 固定示例 0（321700B）、示例 1（163200B）、2.035s 静音（65120B）。输入为已读取文件的分块排期，不是麦克风采集。

## 场景及判据

1. 两场语音：首个非空结果回调时原始输入尚未全部读出；消息 Seq 连续、同 segment ID 完整快照替换；恰好一次 final，随后客户端核实 completed，FinalOffset 等于原始输入，CompletionAckWritten=true。正常收尾后五秒内 Gateway 活动数归零，早于默认 30 秒结果保留到期。
2. 静音：允许没有非空结果，空文本 final 后正常 completed，源恰好 Close 一次，活动数归零。
3. 第一条非空 partial 后取消：Run 返回取消、不报告 completed；源只读出前缀并关闭一次。客户端退出不发送业务取消命令，普通断开保留原 RPC 到默认恢复窗口到期；记录 Run 返回时活动数及随后自然归零，不在观察前主动取消 Gateway 或关闭 Worker。
4. 取消后新场：先分别观察 Gateway 活动数归零及原生释放日志，再开始静音新场，正常 completed，证明当前实例能复用。

通过透明 gRPC 客户端观察器记录成功 Send 的音频字节总量、块长度和 SHA256；完整场必须与原始 PCM 相同。该证据定位 Gateway 发往 Worker 的传输边界，不冒充模型处理前缀。记录 Worker 返回快照与应用回调消息，完整场逐条一致，取消场只比较已应用前缀。

消费者在单个 Run 内按 segment ID 替换快照，逐场独立保存；不把不同逻辑会话的 "1" 片段放进同一个表。单测用改写、删除和空 final 验证示例消费者，真实输出不保证恰好出现这些全部修订类型。

## 记录口径与边界

首条非空结果等待从 V2Client.Run 发起计时，包含握手、按场模型加载、客户端排期和网络；不是对应语音的逐词延迟。尾部从源首次读出 EOF 到 Run 返回，包含 end、模型刷新、final/completed 及客户端确认/清理，与直接 gRPC 的 CloseSend→EOF 不直接比较优化收益。

客户端 Completed、CompletionAckWritten、Gateway 活动数归零和原生 Close 返回分别记录。取消后的清理等待包含默认恢复窗口，不能当作模型取消速度；其先后顺序也不能用来声称跨实例恢复、硬取消或无泄漏。处理进度与 CER 保持未知，未提供独立人工参考。

保存逐条 gRPC/应用结果、源读取和关闭统计、Gateway 快照、运行条件、模型创建/释放日志及源码/二进制摘要；保留首次失败。最后才执行夹具清理，不能让兜底清理充当自然退出证据。

"""Replay damaged comparison evidence; successful slots must not be invented."""
import json
from pathlib import Path
import shutil
import tempfile

from recheck import ROOT, compare


def check():
    rows=[]
    for mutation in ['profile','model','binary','wav','decoding','text','close','finish','failure','missing-exit','frozen-model','missing-slot']:
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'collection'
            shutil.copytree(ROOT,root,ignore=shutil.ignore_patterns('__pycache__'))
            if mutation in ['failure','missing-exit','missing-slot']:
                path=root/'execution.json'
                data=json.loads(path.read_text())
                if mutation=='failure':
                    next(r for r in data if r['name']=='B_q04').update(exit_code=124,timed_out=True)
                elif mutation=='missing-exit':
                    next(r for r in data if r['name']=='B_q04')['exit_code']=None
                else:
                    data.pop()
            elif mutation=='frozen-model':
                path=root/'before-run.json'
                data=json.loads(path.read_text())
                data['models']['B']['files']['encoder.int8.onnx']='changed'
            else:
                path=root/'B_q04/summary.json'
                data=json.loads(path.read_text())
                if mutation=='profile': data['model_profile']['id']='zipformer-bilingual-2023'
                elif mutation=='model': data['file_sha256']['encoder.int8.onnx']='changed'
                elif mutation=='binary': data['file_sha256']['probe_binary']='changed'
                elif mutation=='wav': data['file_sha256']['input.wav']='changed'
                elif mutation=='decoding': data['decoding']['method']='modified_beam_search'
                elif mutation=='text': data['metrics']['last_text_snapshot']='silent correction'
                elif mutation=='close': data['metrics']['close_returned']=False
                else: data['metrics']['input_finished']=False
            path.write_text(json.dumps(data))
            if mutation in ['frozen-model','missing-slot']:
                try:
                    compare(root)
                except (AssertionError,ValueError,KeyError):
                    rows.append({'mutation':mutation,'rejected':True})
                else:
                    raise AssertionError('accepted '+mutation)
            else:
                result=compare(root)
                assert not result['all_six_pairs_complete'] and result['cer_reduction_percentage_points'] is None
                group=result['groups']['B']
                assert group['completed']==5 and group['failed' if mutation=='failure' else 'unknown']==1
                rows.append({'mutation':mutation,'kept_planned':result['planned'],'completed_B':group['completed'],'overall_gain_suppressed':True})
    return rows


if __name__=='__main__':
    print(json.dumps(check(),indent=2))

"""Recompute frozen model comparison and clock quality without native inference."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source/experiments/asrprobe'))
sys.path.insert(0,str(ROOT/'source/experiments/asrquality'))
from compare_models import compare


def sampling_quality(root):
    rows=[json.loads(line) for line in (root/'clock-samples.jsonl').read_text().splitlines()]
    assert len(rows)>=2
    gaps=[{'previous_utc':a['utc'],'next_utc':b['utc'],'monotonic_delta_ns':b['monotonic_ns']-a['monotonic_ns'],
           'wall_delta_ns':b['wall_ns']-a['wall_ns']} for a,b in zip(rows,rows[1:])]
    assert all(g['monotonic_delta_ns']>0 for g in gaps)
    return {'samples':len(rows),'max_monotonic_interval_ns':max(g['monotonic_delta_ns'] for g in gaps),
            'max_wall_interval_ns':max(g['wall_delta_ns'] for g in gaps),
            'gaps_over_3s':[g for g in gaps if max(g['monotonic_delta_ns'],g['wall_delta_ns'])>3_000_000_000]}


def recheck(root):
    frozen=json.loads((root/'before-run.json').read_text())
    for name,digest in frozen['sources_sha256'].items():
        assert hashlib.sha256((root/'source'/name).read_bytes()).hexdigest()==digest,name
    assert sampling_quality(root)==json.loads((root/'sampling-quality.json').read_text())
    result=compare(root)
    assert result==json.loads((root/'comparison.json').read_text())
    return result


if __name__=='__main__':
    result=recheck(ROOT)
    print(json.dumps({k:result[k] for k in ['groups','all_six_pairs_complete','cer_reduction_percentage_points']},ensure_ascii=False,indent=2))

"""Freeze and execute twelve local model comparison slots; preserve every slot."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import wave

REPO = Path('/Users/can/src/golang/tide-personal')
ROOT = Path('/private/tmp/tide-model-comparison-2026-10-26-1')
INPUTS = REPO/'testdata/asr-quality/self-recorded-2026-10-26'
BASELINE = Path('/private/tmp/tide-decoding-comparison-2026-10-26-1/baseline')
PREP = Path('/private/tmp/tide-model-preparation-2026-10-26')
MODEL_DIRS = {'A':Path('/private/tmp/tide-asrprobe-assets-2026-10-25'), 'B':PREP/'locked-model'}
BINARY = Path('/private/tmp/tide-model-comparison-probe-2026-10-26')
SDK = Path('/private/tmp/tide-asrprobe-modcache/github.com/k2-fsa/sherpa-onnx-go-macos@v1.13.8')
sys.path.insert(0,str(REPO/'experiments/asrprobe'))
sys.path.insert(0,str(REPO/'experiments/asrquality'))
from compare_models import PLAN, PROFILES, compare, expected_model


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def main():
    ROOT.mkdir()
    (ROOT/'baseline').mkdir()
    for name in ['input-manifest.json','score.json']:
        shutil.copyfile(BASELINE/name,ROOT/'baseline'/name)
    manifest=json.loads((ROOT/'baseline/input-manifest.json').read_text())
    assert (INPUTS/'manifest.json').read_bytes()==(ROOT/'baseline/input-manifest.json').read_bytes()
    input_files={}
    for case in manifest['cases']:
        for path,expected in [(INPUTS/case['wav_file'],case['wav_sha256']),
                              (INPUTS/case['reference_file'],case['reference_sha256']),
                              (Path(case['source_file']),case['source_sha256'])]:
            assert sha(path)==expected,(path,'changed input')
            input_files[str(path)]=expected
        with wave.open(str(INPUTS/case['wav_file'])) as source:
            assert (source.getframerate(),source.getnchannels(),source.getsampwidth())==(16000,1,2)
            pcm=source.readframes(source.getnframes())
        assert len(pcm)==case['pcm_bytes'] and hashlib.sha256(pcm).hexdigest()==case['pcm_sha256']
    sources={}
    for directory in ['experiments/asrprobe','experiments/asrquality']:
        for path in sorted((REPO/directory).iterdir()):
            if not path.is_file() or (path.suffix not in ('.go','.py','.json','.md') and path.name not in ('go.mod','go.sum')):
                continue
            rel=path.relative_to(REPO)
            target=ROOT/'source'/rel
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(path,target)
            sources[str(rel)]=sha(path)
    for name in ['docs/experiments/real-asr-model-comparison.md','docs/worklog/2026-10-26-real-asr-model-comparison-design.md','docs/worklog/2026-10-26-real-asr-model-smoke.md']:
        target=ROOT/'source'/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(REPO/name,target)
        sources[name]=sha(REPO/name)
    shutil.copyfile(__file__,ROOT/'run.py')
    shutil.copyfile('/private/tmp/tide-model-comparison-python-2026-10-26.log',ROOT/'python-tests.log')
    (ROOT/'preparation').mkdir()
    for name in ['selected-asset.json','upstream-info.json','maintainer-info.json','maintainer-card.md']:
        shutil.copyfile(PREP/name,ROOT/'preparation'/name)
    for name in ['onnx-metadata.json','legacy-onnx-metadata.json','feature-selection-source.json','online-recognizer-transducer-impl.h','export-readme.md']:
        shutil.copyfile(Path('/private/tmp/tide-model-smoke-2026-10-26-1/preparation')/name,ROOT/'preparation'/name)
    (ROOT/'preparation/use-terms-review.txt').write_text(
        '2026-10-26: public upstream page still requires login/acceptance; no explicit weight license obtained. '
        'Export README and fixed maintainer README do not state weight license. '
        'This local public-release measurement does not resolve adoption/distribution terms. '
        'Pre-run plan explicitly adjusts the earlier experiment gate; no gated checkpoint accessed, terms accepted, or audio uploaded.\n'
        'https://huggingface.co/yuekai/icefall-asr-multi-zh-hans-zipformer-large\n'
        'https://huggingface.co/csukuangfj/icefall-asr-multi-zh-hans-zipformer-large/blob/d17b865e7988f9e2f67d2b8bb4af24aa3be09f48/README.md\n')
    models={g:expected_model(p) for g,p in PROFILES.items()}
    model_files={}
    for group,expectation in models.items():
        for name,digest in expectation['files'].items():
            path=MODEL_DIRS[group]/name
            assert sha(path)==digest
            model_files[str(path)]=digest
    dylibs={str(p):sha(p) for p in sorted(SDK.rglob('*.dylib'))}
    write(ROOT/'before-run.json',{'schema':'tide.asr-model-comparison.v1','frozen_utc':utc(),'plan':PLAN,
        'models':models,'model_paths':{g:str(p) for g,p in MODEL_DIRS.items()},'model_file_sha256':model_files,
        'baseline_sha256':{n:sha(ROOT/'baseline'/n) for n in ['input-manifest.json','score.json']},
        'sources_sha256':sources,'input_files_sha256':input_files,'probe_sha256':sha(BINARY),'dylib_sha256':dylibs,
        'sdk_go_source_sha256':sha(SDK/'sherpa_onnx.go'),'process_timeout_seconds':60,'sample_interval_seconds':0.5,
        'sampling_gap_threshold_seconds':3,'weight_use_terms':'unresolved; local measurement only',
        'feature_recipe_difference':'B model metadata selects Whisper feature; not weights-only comparison'})
    rows=[{'name':name,'exit_code':None,'timed_out':False,'started_utc':None,'ended_utc':None} for name in PLAN]
    write(ROOT/'execution.json',rows)
    stopped=threading.Event()
    samples=[]
    def sample():
        with (ROOT/'clock-samples.jsonl').open('x') as output:
            while True:
                row={'utc':utc(),'monotonic_ns':time.monotonic_ns(),'wall_ns':time.time_ns()}
                samples.append(row)
                output.write(json.dumps(row)+'\n')
                output.flush()
                if stopped.wait(0.5):
                    break
    awake=subprocess.Popen(['caffeinate','-i'])
    sampler=threading.Thread(target=sample)
    sampler.start()
    try:
        for row in rows:
            group,identifier=row['name'].split('_')
            case=next(c for c in manifest['cases'] if c['id']==identifier)
            command=[str(BINARY),'-model-profile',PROFILES[group],'-model-dir',str(MODEL_DIRS[group]),
                     '-wav',str(INPUTS/case['wav_file']),'-output',str(ROOT/row['name']),
                     '-threads','2','-realtime=true','-decoding-method','greedy_search','-max-active-paths','0']
            row.update(command=command,started_utc=utc())
            begin=time.monotonic_ns()
            with (ROOT/(row['name']+'.stdout')).open('xb') as stdout, (ROOT/(row['name']+'.stderr')).open('xb') as stderr:
                try:
                    row['exit_code']=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=60).returncode
                except subprocess.TimeoutExpired:
                    row.update(exit_code=124,timed_out=True)
            row.update(ended_utc=utc(),process_elapsed_ns=time.monotonic_ns()-begin)
            write(ROOT/'execution.json',rows)
            print(row['name'],row['exit_code'],flush=True)
    finally:
        stopped.set()
        sampler.join()
        awake.terminate()
        awake.wait()
    gaps=[{'previous_utc':a['utc'],'next_utc':b['utc'],'monotonic_delta_ns':b['monotonic_ns']-a['monotonic_ns'],
           'wall_delta_ns':b['wall_ns']-a['wall_ns']} for a,b in zip(samples,samples[1:])]
    write(ROOT/'sampling-quality.json',{'samples':len(samples),'max_monotonic_interval_ns':max(g['monotonic_delta_ns'] for g in gaps),
        'max_wall_interval_ns':max(g['wall_delta_ns'] for g in gaps),
        'gaps_over_3s':[g for g in gaps if max(g['monotonic_delta_ns'],g['wall_delta_ns'])>3_000_000_000]})
    result=compare(ROOT)
    write(ROOT/'comparison.json',result)
    before=json.loads((ROOT/'before-run.json').read_text())
    assert all(sha(REPO/n)==d for n,d in sources.items())
    assert all(sha(Path(n))==d for n,d in {**input_files,**model_files,**dylibs}.items())
    assert sha(BINARY)==before['probe_sha256']
    write(ROOT/'after-run-check.json',{'checked_utc':utc(),'sources_unchanged':True,'inputs_unchanged':True,
        'models_unchanged':True,'dylibs_unchanged':True,'binary_unchanged':True})
    print(json.dumps({k:result[k] for k in ['groups','all_six_pairs_complete','cer_reduction_percentage_points']},ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    main()

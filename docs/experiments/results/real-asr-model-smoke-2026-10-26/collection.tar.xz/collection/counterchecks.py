"""Damaged evidence must fail reconciliation; originals remain unchanged."""
import json
from pathlib import Path
import shutil
import tempfile

from recheck import ROOT, recheck


def check():
    outcomes=[]
    for mutation in ['profile','encoder','lock','missing-profile','padding','text','close']:
        with tempfile.TemporaryDirectory() as tmp:
            clone=Path(tmp)/'collection'
            shutil.copytree(ROOT,clone,ignore=shutil.ignore_patterns('__pycache__'))
            path=clone/'speech-0/summary.json'
            r=json.loads(path.read_text())
            if mutation=='profile': r['model_profile']['id']='zipformer-bilingual-2023'
            elif mutation=='encoder': r['file_sha256']['encoder.int8.onnx']='changed'
            elif mutation=='lock': r['file_sha256']['model_asset_lock']='changed'
            elif mutation=='missing-profile': r.pop('model_profile')
            elif mutation=='padding': r['stream_config']['trailing_padding_samples']=8000
            elif mutation=='text': r['metrics']['last_text_snapshot']='silent text correction'
            else: r['metrics']['close_returned']=False
            path.write_text(json.dumps(r))
            try:
                recheck(clone)
            except (AssertionError,KeyError,ValueError):
                outcomes.append({'mutation':mutation,'rejected':True})
            else:
                raise AssertionError('accepted mutation: '+mutation)
    return outcomes


if __name__=='__main__':
    print(json.dumps(check(),indent=2))

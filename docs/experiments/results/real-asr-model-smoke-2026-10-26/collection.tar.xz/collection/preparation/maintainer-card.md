# Introduction

Cloned from
https://huggingface.co/yuekai/icefall-asr-multi-zh-hans-zipformer-large

See also
https://github.com/k2-fsa/icefall/blob/master/egs/multi_zh-hans/ASR/RESULTS.md#multi-chinese-datasets-char-based-training-results-streaming-on-zipformer-large-model
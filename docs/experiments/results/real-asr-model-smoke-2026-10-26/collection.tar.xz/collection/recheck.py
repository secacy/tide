"""Reconcile the frozen smoke evidence without model files or native inference."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'source/experiments/asrprobe'))
from model_assets import expected_model
from verify import verify_case


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def recheck(root):
    frozen = json.loads((root/'before-run.json').read_text())
    assert frozen['schema'] == 'tide.asr-model-smoke.v1' and frozen['quality_experiment'] is False
    assert [r['name'] for r in frozen['plan']] == ['speech-0','speech-1','silence','canceled','legacy-speech']
    for name, digest in frozen['sources'].items():
        assert sha(root/'source'/name) == digest, name
    assert sha(root/'source/experiments/asrprobe/model-assets.json') == frozen['asset_lock_sha256']
    executions = json.loads((root/'execution.json').read_text())
    assert [r['name'] for r in executions] == [r['name'] for r in frozen['plan']]
    rows = []
    for case, execution in zip(frozen['plan'],executions):
        name = case['name']
        assert not execution['timed_out']
        expected = expected_model(case['profile'])
        verified = verify_case(root,execution,expected_model=expected)
        report = json.loads((root/name/'summary.json').read_text())
        m = report['metrics']
        assert report['file_sha256']['probe_binary'] == frozen['probe_sha256']
        assert report['file_sha256']['model_asset_lock'] == frozen['asset_lock_sha256']
        for filename, digest in expected['files'].items():
            assert frozen['models'][str(Path(case['dir'])/filename)] == digest
        if 'wav' in case:
            input_info = frozen['inputs'][case['wav']]
            assert report['file_sha256']['input.wav'] == input_info['sha256']
            assert (input_info['rate'],input_info['channels'],input_info['width']) == (16000,1,2)
            assert m['input_bytes'] == input_info['samples']*2
        else:
            assert case['silence'] == '2035ms' and m['input_bytes'] == 65120
        events = [json.loads(line) for line in (root/name/'events.jsonl').read_text().splitlines()]
        assert [e['samples'] for e in events if e['kind']=='leading_padding'] == [4800]
        chunks = [e['samples'] for e in events if e['kind']=='input']
        count = m['input_bytes']//2
        all_chunks = [min(1600,count-pos) for pos in range(0,count,1600)]
        if name == 'canceled':
            assert case['cancel_after']=='350ms' and report['cancel_after_ns']==350000000
            assert 0 < m['submitted_bytes'] < m['input_bytes']
            assert chunks == all_chunks[:len(chunks)]
        else:
            assert report['cancel_after_ns']==0 and chunks==all_chunks
            assert [e['samples'] for e in events if e['kind']=='trailing_padding'] == [9600]
        if name.startswith('speech') or name=='legacy-speech':
            assert m['first_text_before_input_end']
        rows.append({'name':name,'profile':case['profile'],'verification':verified,'metrics':m,
                     'load_ns':report['load_ns'],'last_chunk_samples':chunks[-1]})
    assert rows == json.loads((root/'summary.json').read_text())
    return rows


if __name__ == '__main__':
    rows = recheck(ROOT)
    print(json.dumps({'verified':len(rows),'names':[r['name'] for r in rows]},indent=2))

"""Run only the model-profile smoke gate, not the six-pair quality experiment."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import wave

REPO = Path('/Users/can/src/golang/tide-personal')
ROOT = Path('/private/tmp/tide-model-smoke-2026-10-26-1')
PREP = Path('/private/tmp/tide-model-preparation-2026-10-26')
MODEL = PREP / 'locked-model'
OLD = Path('/private/tmp/tide-asrprobe-assets-2026-10-25')
BINARY = Path('/private/tmp/tide-model-profile-probe-2026-10-26')
SDK = Path('/private/tmp/tide-asrprobe-modcache/github.com/k2-fsa/sherpa-onnx-go-macos@v1.13.8')


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def varint(f):
    value = 0
    for shift in range(0, 70, 7):
        b = f.read(1)
        if not b:
            raise EOFError('truncated protobuf varint')
        value |= (b[0] & 127) << shift
        if b[0] < 128:
            return value
    raise ValueError('oversized protobuf varint')


def fields(f, end):
    # Inspect top-level protobuf fields only; skip large graph/tensor payloads.
    while f.tell() < end:
        key = varint(f)
        wire, number = key & 7, key >> 3
        if wire == 0:
            yield number, varint(f)
        elif wire == 2:
            length = varint(f)
            if f.tell() + length > end:
                raise ValueError('field exceeds enclosing message')
            if number == 14 or isinstance(f, io.BytesIO):
                yield number, f.read(length)
            else:
                f.seek(length, 1)
        elif wire in (1, 5):
            f.seek(8 if wire == 1 else 4, 1)
        else:
            raise ValueError('unexpected wire type')
    if f.tell() != end:
        raise ValueError('invalid protobuf bounds')


def metadata(path):
    result = {}
    with path.open('rb') as f:
        for number, value in fields(f, path.stat().st_size):
            if number == 14:
                pair = dict(fields(io.BytesIO(value), len(value)))
                k, v = pair[1].decode(), pair[2].decode()
                if k in result:
                    raise ValueError('duplicate metadata key')
                result[k] = v
    return result


def main():
    ROOT.mkdir()
    source_files = sorted(p for p in (REPO/'experiments/asrprobe').iterdir()
                          if p.suffix in ('.go', '.py', '.json') or p.name in ('go.mod', 'go.sum', 'README.md'))
    source_files += [REPO/'docs/worklog/2026-10-26-real-asr-model-comparison-design.md',
                     REPO/'experiments/asrquality/test_model_profiles.py']
    sources = {}
    for path in source_files:
        rel = path.relative_to(REPO)
        target = ROOT/'source'/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        sources[str(rel)] = sha(path)
    shutil.copyfile(__file__, ROOT/'run.py')
    evidence = ROOT/'preparation'
    evidence.mkdir()
    for name in ('release.json', 'selected-asset.json', 'upstream-info.json', 'maintainer-info.json', 'maintainer-card.md'):
        shutil.copyfile(PREP/name, evidence/name)
    (evidence/'first-attempts.txt').write_text(
        'Initial upstream README request returned HTTP 401; public metadata confirms gated=auto, no cardData. '
        'Export README and maintainer clone README do not declare a weight license.\n'
        'First formatting command used repository-relative paths from the probe subdirectory and failed lstat; '
        'corrected to local filenames. Tests still ran and passed. No inference was attempted before correction.\n')
    write(evidence/'onnx-metadata.json', {name: metadata(MODEL/name) for name in ('encoder.int8.onnx', 'decoder.onnx', 'joiner.int8.onnx')})
    lock = json.loads((REPO/'experiments/asrprobe/model-assets.json').read_bytes())
    plan = [
        {'name':'speech-0','profile':'zipformer-zh-2025','dir':str(MODEL),'wav':str(MODEL/'test_wavs/0.wav')},
        {'name':'speech-1','profile':'zipformer-zh-2025','dir':str(MODEL),'wav':str(MODEL/'test_wavs/1.wav')},
        {'name':'silence','profile':'zipformer-zh-2025','dir':str(MODEL),'silence':'2035ms'},
        {'name':'canceled','profile':'zipformer-zh-2025','dir':str(MODEL),'wav':str(MODEL/'test_wavs/0.wav'),'cancel_after':'350ms'},
        {'name':'legacy-speech','profile':'zipformer-bilingual-2023','dir':str(OLD),'wav':str(OLD/'test_wavs/0.wav')},
    ]
    inputs = {}
    for case in plan:
        if 'wav' in case:
            path = Path(case['wav'])
            with wave.open(str(path)) as f:
                pcm = f.readframes(f.getnframes())
                inputs[str(path)] = {'sha256':sha(path),'pcm_sha256':hashlib.sha256(pcm).hexdigest(),
                                     'samples':f.getnframes(),'rate':f.getframerate(),'channels':f.getnchannels(),'width':f.getsampwidth()}
    expected_files = {}
    for case in plan:
        for name, digest in lock['profiles'][case['profile']]['files'].items():
            path = Path(case['dir'])/name
            assert sha(path) == digest
            expected_files[str(path)] = digest
    dylibs = {str(p): sha(p) for p in sorted(SDK.rglob('*.dylib'))}
    write(ROOT/'before-run.json', {'schema':'tide.asr-model-smoke.v1','frozen_utc':utc(), 'plan':plan,
                                 'sources':sources, 'models':expected_files,'inputs':inputs,'probe_sha256':sha(BINARY),
                                 'dylib_sha256':dylibs,'asset_lock_sha256':sha(REPO/'experiments/asrprobe/model-assets.json'),
                                 'quality_experiment':False, 'weight_license':'unresolved'})
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
               GOCACHE='/private/tmp/tide-review-gocache', GOMODCACHE='/private/tmp/tide-asrprobe-modcache', GOPROXY='off', GOSUMDB='off')
    for name, cmd, cwd in [
        ('go-race', ['go','test','-race','./...'],REPO/'experiments/asrprobe'),
        ('go-vet', ['go','vet','./...'],REPO/'experiments/asrprobe'),
        ('python-assets', [sys.executable,'-m','unittest','discover','-s','experiments/asrprobe','-p','test_*.py','-v'],REPO),
        ('python-quality', [sys.executable,'-m','unittest','discover','-s','experiments/asrquality','-p','test_*.py','-v'],REPO),
    ]:
        env['PYTHONPATH']=str(REPO/'experiments/asrprobe')+':'+str(REPO/'experiments/asrquality')
        result = subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,timeout=60)
        (ROOT/(name+'.log')).write_bytes(result.stdout+result.stderr)
        assert result.returncode == 0, name
    awake = subprocess.Popen(['caffeinate','-i'])
    executions = []
    try:
        for case in plan:
            command = [str(BINARY),'-model-profile',case['profile'],'-model-dir',case['dir'],'-output',str(ROOT/case['name'])]
            command += ['-wav',case['wav']] if 'wav' in case else ['-silence',case['silence']]
            if 'cancel_after' in case:
                command += ['-cancel-after',case['cancel_after']]
            row = {'name':case['name'],'command':command,'started_utc':utc(),'timed_out':False}
            start = time.monotonic_ns()
            try:
                result = subprocess.run(command,cwd=REPO,env=env,capture_output=True,timeout=60)
                row['exit_code'] = result.returncode
                stdout, stderr = result.stdout, result.stderr
            except subprocess.TimeoutExpired as error:
                row.update(exit_code=None,timed_out=True)
                stdout, stderr = error.stdout or b'', error.stderr or b''
            row.update(ended_utc=utc(), process_elapsed_ns=time.monotonic_ns()-start)
            (ROOT/(case['name']+'.stdout')).write_bytes(stdout)
            (ROOT/(case['name']+'.stderr')).write_bytes(stderr)
            executions.append(row)
            write(ROOT/'execution.json',executions)
            print(case['name'],row['exit_code'],flush=True)
    finally:
        awake.terminate()
        awake.wait()
    sys.path.insert(0,str(REPO/'experiments/asrprobe'))
    from verify import verify_case
    from model_assets import expected_model
    summary = []
    for case, execution in zip(plan,executions):
        assert not execution['timed_out']
        verification = verify_case(ROOT,execution,expected_model=expected_model(case['profile']))
        report = json.loads((ROOT/case['name']/'summary.json').read_bytes())
        metrics = report['metrics']
        assert report['file_sha256']['probe_binary'] == sha(BINARY)
        if 'wav' in case:
            assert report['file_sha256']['input.wav'] == inputs[case['wav']]['sha256']
        chunks = [e['samples'] for e in map(json.loads,(ROOT/case['name']/'events.jsonl').read_text().splitlines()) if e['kind']=='input']
        if case['name'] == 'legacy-speech':
            assert metrics['first_text_before_input_end']
        summary.append({'name':case['name'],'profile':case['profile'],'verification':verification,
                        'metrics':metrics,'load_ns':report['load_ns'],'last_chunk_samples':chunks[-1]})
    write(ROOT/'summary.json',summary)
    frozen = json.loads((ROOT/'before-run.json').read_text())
    assert all(sha(REPO/name)==digest for name,digest in sources.items())
    assert all(sha(Path(name))==digest for name,digest in {**expected_files,**dylibs}.items())
    assert sha(BINARY)==frozen['probe_sha256']
    write(ROOT/'after-run.json',{'checked_utc':utc(),'sources_unchanged':True,'models_unchanged':True,'dylibs_unchanged':True,'binary_unchanged':True})
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)


if __name__ == '__main__':
    main()
